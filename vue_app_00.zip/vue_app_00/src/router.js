import Vue from 'vue'
import Router from 'vue-router'
import HelloContainer from "./components/HelloWorld.vue"
import Home from "./components/tabbar/Home.vue"
import Cakelist from "./components/goods/Cakelist.vue"
import Cakeinfo from "./components/goods/Cakeinfo.vue"
import Login from "./components/goods/Login.vue"
import ShopCart from "./components/goods/ShopCart.vue"
import Search from "./components/goods/Search.vue"
import Breadlist from "./components/goods/Breadlist.vue"
import Breadinfo from "./components/goods/Breadinfo.vue"
import Coffeelist from "./components/goods/Coffeelist.vue"
import Coffeeinfo from "./components/goods/Coffeeinfo.vue"
Vue.use(Router)

export default new Router({
  routes: [
   // {path:'/',component:HelloContainer},
       {path:'/',redirect:'/Home'},
       {path:'/Home',component:Home},
       {path:'/Cakelist',component:Cakelist},
       {path:'/Cakeinfo',component:Cakeinfo},
       {path:'/Login',component:Login},
       {path:'/ShopCart',component:ShopCart},
       {path:'/Search',component:Search},
       {path:'/Breadlist',component:Breadlist},
       {path:'/Breadinfo',component:Breadinfo},
       {path:'/Coffeelist',component:Coffeelist},
       {path:'/Coffeeinfo',component:Coffeeinfo}

  ]
})
