<template>
    <div class="app-goodslist">
     <div class="goods-item" v-for="(item,i) of list" :key="i.id">
         <img :src="'http://127.0.0.1:3000/'+item.img_url"   @click="jumpInfo"  :data-id="item.id">
         <h4>{{item.title}}</h4>
         <div class="info">
            <span class="now">￥{{item.price}}</span>
         </div>
         <div class="sell">
           <span>{{item.count}}</span>
         </div>
         <div> {{item.subtitle}}</div>
     </div>
     <mt-button type="primary" size="large" @click="getMore">加载更多</mt-button>
    </div>
</template>
<script>
  import {Toast}from "mint-ui";
    export default{
        data(){
            return{
                list:[],
                pno:0,
                pageSize:4
            }
        },
        methods:{
            jumpInfo(e){
                var id=e.target.dataset.id;
                this.$router.push("/Cakeinfo?id="+id)
            },
            getMore(){
                this.pno++;
                var url="http://127.0.0.1:3000/index";
                url+="/cake?pno="+this.pno;
                url+="&pageSize="+this.pageSize;
                this.axios.get(url).then(result=>{
                   // console.log(result.data.data)
                 var rows=this.list.concat(result.data.data);
                 this.list=rows;
                })
            },
            getGoodslist(){
                var url="http://127.0.0.1:3000/index/cake";
                this.axios.get(url).then(result=>{
                    this.list=result.data.data
                })
            }
        },
        created() {
            this.getGoodslist();
        },
    }
</script>
<style>
    .app-goodslist{
        display:flex;
        flex-wrap:wrap;
        justify-content:space-between;
        padding:4px;
    }
    .app-goodslist .goods-item{
        width:49%;
        border:1px solid #ccc;
        box-shadow:0 0 8px #ccc;
        margin:4px 0;
        padding:2px;
        display:flex;
        flex-direction:column;
        min-height:230px;
        justify-content:space-between;
        text-align:center;
    }
    .app-goodslist .goods-item img{width:100%}
    .app-goodslist .goods-item h4{font-size:16px;}
    .app-goodslist .goods-item .now{
        color:red;
        font-size:16px;
        font-weight:bold;
    }
    .addCart{
        background-color:#0aa1ed;
        width:200px;
        height:30px;
        line-height:30px;
    }
</style>