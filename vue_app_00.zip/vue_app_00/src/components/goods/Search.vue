<template>
    <div>
       <input type="text" name="key" v-model="key">
       <mt-button type="primary" size="large" @click="search">搜索</mt-button>
  <div class="app-goodslist">
    <div class="goods-item" v-for="item of list" :key="item.id" >
       <img :src="'http://127.0.0.1:3000/'+item.img_url" @click="jumpInfo" :data-id="item.id">
       <h4>{{item.id}}</h4>
       <div class="info">
           <span class="now">{{item.title}}</span>
           <p>{{item.price}}<span>{{item.count}}</span></p>
       </div>
       <div class="sell">
            <span>{{item.subtitle}}</span>
       </div>
    </div></div>
  </div>
</template>
<script>
    export default{
        data(){
            return{
                list:[],
                pno:0,
                pageSize:4,
                key:''
            }
        },
        methods:{
            //页面跳转
            jumpInfo(e){
                var id=e.target.dataset.id;
                this.$router.push("/Cakeinfo?id="+id)
            },
            //商品搜索
          search(){
              //测试点击
              //console.log(123);
             this.pno++;
             //发送ajax请求
             var url="http://127.0.0.1:3000/index";
             url+="/search?key="+this.key;
             url+="&pno="+this.pno;
             url+="&pageSize="+this.pageSize;
             this.axios.get(url).then(result=>{
                 var rows=this.list.concat(result.data.data);
                 this.list=rows;
                // console.log(this.list);
             })
          }
        },
    }
</script>
<style>
    .app-goodslist{
      display:flex;
      flex-wrap:wrap;
      justify-content:space-between;
      padding:4px;
    }
    .app-goodslist .goods-item{
      width:49%;
      border:1px solid #ccc;
      box-shadow:0 0 8px #ccc;
      margin:4px 0;
      padding:2px;
      display:flex;
      flex-direction:column;
      min-height:230px;
      justify-content:space-between;
      text-align:center;
    }
    .app-goodslist .goods-item img{width:100%}
    .app-goodslist .goods-item h4{font-size:12px;}
    .app-goodslist .goods-item .now{
      color:red;
      font-size:16px;
      font-weight:bold;
    }
</style>