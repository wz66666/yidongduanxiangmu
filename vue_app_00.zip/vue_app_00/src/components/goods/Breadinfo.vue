<template>
   <div class="app-goodinfo">
      <div class="mui-card">
				<div class="mui-card-content">
					<div class="mui-card-content-inner">
					   <swiper-box :list="rows"></swiper-box>
					</div>
			   </div>	
        </div>
            <!--调用-->
        <div class="mui-card">
				<div class="mui-card-header">商品信息</div>
				<div class="mui-card-content">
					<div class="mui-card-content-inner">
                        <p>商品名称: {{info.title}}</p>
						<p>销售价：{{info.price}}</p>
                        购买数量：<div class="mui-numbox">
					<button class="mui-btn mui-btn-numbox-minus" type="button" @click="goodSub">-</button>
					<input class="mui-input-numbox" type="number" value="1" v-model="val"/>
					<button class="mui-btn mui-btn-numbox-plus" type="button" @click="goodAdd">+</button>
				</div>
					</div>
				</div>
				<div class="mui-card-footer">
                  <mt-button type="danger" size=small @click="addcart">加入购物车</mt-button>
                </div>
			</div>    
  </div>
</template>
<script>
    import  {Toast} from 'mint-ui'
    import swiperBox from '../sub/swiperBox.vue'
    export default{
        data(){
            return{
                rows:[],
                info:{},
                id:this.$route.query.id,
                val:1
            }
        },
        methods:{
            goodAdd(){
                this.val++;
            },
            goodSub(){
                if(this.val>1){
                    this.val--;
                }
            },
            findGoodsinfo(){
                var url="http://127.0.0.1:3000/index/breadInfo?id="+this.id;
                this.axios.get(url).then(result=>{
                    this.info=result.data;
                })
            },
             getImages(){
             var url = "http://127.0.0.1:3000/index/imglist";
             this.axios.get(url).then(result=>{
               this.rows = result.data;
               //console.log(result)
             });
            },
            addcart(){
                //绑定事件
               // console.log(123)
               //获取两个参数
               var pid=this.id;
               var price=this.info.price;
               var uid=1;
                var count=this.val;
               //console.log(pid+'-'+price+'-'+uid)
               //ajax请求
               var url="http://127.0.0.1:3000/index/"
               url+="addcart?pid="+pid;
               url+="&price="+price;
               url+="&uid="+uid;
                 url+="&count="+count;
               this.axios.get(url).then(result=>{
                   if(result.data.code==1){
                       Toast("添加成功");
                       //1:创建变量保存url
                var url="http://127.0.0.1:3000/index/";
                url+="cartlist";
                //发送ajax请求
                this.axios.get(url).then(result=>{
                      if(result.data.code == -1){
                       Toast("请登录");
                        return;
                        }
                    //console.log(result.data)
                     //1:2 没有与 vue data双向绑定 
                    //1:接收服务器程序返回数据
                    //ShopCart.vue 
                    var rows=result.data.data;
                    //购物车数量
                    this.$store.commit("updateCount",rows.length);
                    //2:为每一个商品对象添加属性cb 选中状态
                    for(var item of rows){
                        item.cb=false;
                    }
                      //3:将最终数组赋值 list 列表   
                    this.list=rows;
                   // console.log(this.list)
                });
                   }else{
                       Toast("请登录")
                   }
               })
            }

           

        },
        created() {
            this.getImages();
            this.findGoodsinfo();
        },
        components:{
            "swiper-box":swiperBox
        }
    }
</script>
<style>
    
</style>