<template>
    <div class="shopcart">
      <div class="mui-card">
				<div class="mui-card-header">
				<h3>购物车列表</h3>
				<h4>全选&nbsp;<input type="checkbox" @click="setAll" :checked="allcb" ></h4>
				</div>
				<div class="mui-card-content">
					<div class="mui-card-content-inner">
                <ul class="mui-table-view">
				<li class="mui-table-view-cell mui-media" v-for="(item,i) in list" :key="item.id">
					<a href="javascript:;">
						<img class="mui-media-object mui-pull-left" :src="'http://127.0.0.1:3000/'+item.img_url">
						<div class="mui-media-body">
							{{item.title}}
							<p class='mui-ellipsis'>
                            <span>￥{{item.price}}
                            </span>
                            <span>购买数量：{{item.count}}
                            </span>
                            <span><button @click="delItem" :data-pid="item.id" :data-idx="i">删除</button></span>
                            </p>
						</div>
					</a><br>
                   <!-- <input type="checkbox" :checked="item.cb" :data-i="i" @click="modifyItem"/>-->
				</li>
			</ul>
            
				</div>
				</div>
				<div class="mui-card-footer"><button @click="removeItem">删除所选的商品</button>小计：￥{{total.toFixed(2)}}</div>
			</div>
         
    </div>
</template>
<script>
    import {Toast} from 'mint-ui'
    export default{
        data(){
            return {
                list:[],
                cb:false,
                allcb:false    
            }
        },
        methods:{
            delItem(e){
                // console.log(e.target)
              var id=e.target.dataset.pid;
              console.log(id)
              var idx=e.target.dataset.idx;//下标

             // console.log(idx)
             var url="http://127.0.0.1:3000/index/";
             url+="delCartItem?id="+id;
             //发送请求
             this.axios.get(url).then(result=>{
                 if(result.data.code==1){
                     Toast("删除成功")
                     this.list.splice(idx,1);
                 }
             })
            },
            loadMore(){
                //1:创建变量保存url
                var url="http://127.0.0.1:3000/index/";
                url+="cartlist";
                //发送ajax请求
                this.axios.get(url).then(result=>{
                      if(result.data.code == -1){
                       Toast("请登录");
                        return;
                        }
                    //console.log(result.data)
                     //1:2 没有与 vue data双向绑定 
                    //1:接收服务器程序返回数据
                    //ShopCart.vue 
                    var rows=result.data.data;
                    //购物车数量
                    this.$store.commit("updateCount",rows.length);
                    //2:为每一个商品对象添加属性cb 选中状态
                    for(var item of rows){
                        item.cb=false;
                    }
                      //3:将最终数组赋值 list 列表   
                    this.list=rows;
                   console.log(this.list)
                });
               
            },
            setAll(e){//全选按钮点击事件
                //1:获取当前全选复选框状态
                    var cb=e.target.checked;
                    //console.log(cb)
                    //2:修改全选状态
                    this.allcb=cb;
                     //2:依据全选状态修改数组中cb值
                    for(var item of this.list){
                     item.cb=cb;
                    }
                },
            modifyItem(e){
                //修改
               //1:获取当前元素下标[其中一种方式]
                var idx=e.target.dataset.i;
                //console.log(idx)
                //2:将下标对象数组中元素cb修改当前复选状态
                var checked=e.target.checked;
                 //3:将数组中对应cb状态修改
                this.list[idx].cb=checked;
                //4:统计购物车中商品选中数量 == list.length
                //5:将全选状态修改为true否则为 false
                var count=0;
                for(var item of this.list){
                    if(item.cb){
                        if(item.cb){
                            count++;
                        }
                    }
                    if(count==this.list.length){
                        this.allcb=true;
                    }else{
                        this.allcb=false;
                    }
                }
            },
            removeItem(){
            //0:创建空字符串，为了后续接拼字符串
                var html="";
                //1:遍历数组中元素
                for(var item of this.list){
                    //2:判断cb==true
                    if(item.cb){
                        //3:保存id：拼字符串
                        html+=item.id+",";
                    }
                } 
                  //3.1:截取字符串  试一下  三 二 一
               html=html.substring(0,html.length-1)
              // console.log(html)
                //4:发送ajax请求 删除多个商品
               var url="http://127.0.0.1:3000/index/";
               url+="removeMItem?ids="+html;
               this.axios.get(url).then
               (result=>{
                   if(result.data.code==1){
                       Toast("删除成功");
                       this.loadMore();
                   }
               });
               
            }    
        },
         computed:{
        total(){console.log("计算了一次总价")
             var sum=0;
             for(var p of this.list){
             sum+=p.price*p.count;
            }
            return sum;
            }},
        created() {
            this.loadMore();
        },
    }
</script>
<style>
     .shopcart li .mui-ellipsis{
        display:flex;
        justify-content:space-between;
        font-size:12px;
        color:#226aff;
    }
</style>