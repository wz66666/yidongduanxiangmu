<template>
    <div class="app-home">
    <!--轮播图-->
   <mt-swipe>
     <mt-swipe-item v-for="item in list" :key="item.id">
         <img :src="'http://127.0.0.1:3000/'+item.img" />
     </mt-swipe-item>
   </mt-swipe>
   <!--九宫格 -->
<ul class="mui-table-view mui-grid-view mui-grid-9">
   <li class="mui-table-view-cell mui-media mui-col-xs-4 mui-col-sm-3">
     <router-link to="/Cakelist">
     <img src="../../img/menu1.png" />
     <div class="mui-media-body">蛋糕</div>
     </router-link>
   </li>
   <li class="mui-table-view-cell mui-media mui-col-xs-4 mui-col-sm-3">
    <router-link to="/Breadlist">
    <img src="../../img/menu2.png" />
    <div class="mui-media-body">面包</div>
    </router-link>
   </li>
   <li class="mui-table-view-cell mui-media mui-col-xs-4 mui-col-sm-3">
   <router-link to="/Coffeelist">
   <img src="../../img/menu3.png" />
   <div class="mui-media-body">咖啡</div>
   </router-link>
   </li>
   <li class="mui-table-view-cell mui-media mui-col-xs-4 mui-col-sm-3">
   <router-link to="/ShopCart">
   <img src="../../img/menu4.png" />
   <div class="mui-media-body">购物车</div>
   </router-link>
   </li>
   <li class="mui-table-view-cell mui-media mui-col-xs-4 mui-col-sm-3">
   <a href="#">
   <img src="../../img/menu5.png" />
   <div class="mui-media-body">支付</div>
   </a>
   </li>
   <li class="mui-table-view-cell mui-media mui-col-xs-4 mui-col-sm-3">
   <router-link to="/Search">
   <img src="../../img/menu6.png" />
   <div class="mui-media-body">搜索</div>
   </router-link>
   </li>
</ul>    
    </div>
  </template>
  <script>
    export default{
        data(){
            return{
                list:[]
            }
        },
        methods:{
        swipeImg(){
        var url="http://127.0.0.1:3000/index/imglist";
        this.axios.get(url).then(result=>{
            this.list = result.data;
        });
        }
        },
        created() {
            this.swipeImg();
        },
    }
</script>
<style >
 /*轮播图*/
    .app-home .mint-swipe{
        height:200px;
    }
    .app-home .mint-swipe img{
        width:100%;
    }
    /*九宫格  图片宽度*/
    .app-home .mui-grid-9 img{
    width:60px;
    height:60px;	 
    }
  /*九宫格  背景修改为白色*/
   .app-home .mui-grid-view.mui-grid-9{
    background-color:#fff; 
   }
</style>