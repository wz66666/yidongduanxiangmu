const express=require('express');
const pool=require('../pool');
const router=express.Router();

//功能一:home组件轮播图片
router.get("/imglist",(req,res)=>{
    var sql=`select * from gyk_imges where id!=0 order by id`;
    //var id=req.query.id;
    //var sql=`select * from bsk_imges where id=?`
    pool.query(sql,[],(err,result)=>{
      if(err) console.log(err);
      var list=result;
      res.send(list)
    })
})
//功能二蛋糕分页显示
router.get("/cake",(req,res)=>{
  //参数
  var pno=req.query.pno;
  var pageSize=req.query.pageSize;
  //允许使用默认值
  if(!pno){pno=1}
  if(!pageSize){pageSize=7}
  //sql
  var sql="SELECT * FROM  gyk_products WHERE family='cake' ";
  sql+=" LIMIT ?,?";
  //json
  var offset=(pno-1)*pageSize;
  pageSize=parseInt(pageSize);
  pool.query(sql,[offset,pageSize],(err,result)=>{
      if(err)throw err;
      res.send({code:1,data:result})
  })
})
//功能3面包分页显示
router.get("/bread",(req,res)=>{
  //参数
  var pno=req.query.pno;
  var pageSize=req.query.pageSize;
  //允许使用默认值
  if(!pno){pno=1}
  if(!pageSize){pageSize=7}
  //sql
  var sql=" SELECT * FROM  gyk_products WHERE family='bread' ";
  sql+=" LIMIT ?,?";
  //json
  var offset=(pno-1)*pageSize;
  pageSize=parseInt(pageSize);
  pool.query(sql,[offset,pageSize],(err,result)=>{
      if(err)throw err;
      res.send({code:1,data:result})
  })
})
//功能4咖啡分页显示
router.get("/coffee",(req,res)=>{
  //参数
  var pno=req.query.pno;
  var pageSize=req.query.pageSize;
  //允许使用默认值
  if(!pno){pno=1}
  if(!pageSize){pageSize=7}
  //sql
  var sql=" SELECT id,title,price";
  sql+=" ,img_url,addcart";
  sql+=" FROM gyk_products where family='coffee'";
  sql+=" LIMIT ?,?";
  //json
  var offset=(pno-1)*pageSize;
  pageSize=parseInt(pageSize);
  pool.query(sql,[offset,pageSize],(err,result)=>{
      if(err)throw err;
      res.send({code:1,data:result})
  })
})
//功能5登录
router.get("/login",(req,res)=>{
  var uname=req.query.uname;
  var upwd=req.query.upwd;
  var sql="SELECT id FROM gyk_login WHERE uname=? AND upwd=md5(?)";
  pool.query(sql,[uname,upwd],(err,result)=>{
      if(err)throw err;
      if(result.length==0){
          res.send({code:-1,msg:"用户名或密码有误"});
      }else{
          var id=result[0].id;//获取当前用户ID
          req.session.uid=id;//保存到sesion
         // console.log(req.session.uid);
          //console.log(req.session.uid);
          res.send({code:1,msg:"登录成功"})
      }
  })
})
//功能6添加购物车
router.get("/addcart",(req,res)=>{
   //判断用户是否登录
   if(!req.session.uid){
    res.send({code:-1,msg:'请登录'})
    return;
  }  
  //参数
  var pid=parseInt(req.query.pid);
  var count=parseInt(req.query.count);
  var uid=req.session.uid;
  //var uid=parseInt(req.query.uid);
  var price=parseInt(req.query.price);
  var sql="SELECT id FROM gyk_cart";
  sql+=" WHERE uid=? AND pid=? AND count=?";
  pool.query(sql,[uid,pid,count],(err,result)=>{
      if(err)throw err;
      if(result.length==0){
        var sql=`INSERT INTO gyk_cart`;
        sql+=` VALUES(null,${count},${price},${pid},${uid})`
      }else{
          var sql=`UPDATE gyk_cart`
          sql+=` SET count=${count} WHERE pid=${pid} AND uid=${uid}`;
      }
      pool.query(sql,(err,result)=>{
          if(err)throw err;
          if(result.affectedRows>0){
              res.send({code:1,msg:"添加成功"})
          }else{
              res.send({code:-1,msg:"添加失败"})
          }
      })
  })
})

//功能7获取购物车列表
router.get("/cartlist",(req,res)=>{
  var uid = req.session.uid;
  if(!uid){
      res.send({code:-1,msg:"请登录"});
      return;
  }
 var sql=" SELECT c.id,c.count,p.price,";
 sql+=" c.pid,p.title,p.img_url" 
 sql+=" FROM gyk_cart as  c,gyk_products as  p";
 sql+=" WHERE c.pid=p.id ";
 sql+=" AND c.uid=?";
 pool.query(sql,[uid],(err,result)=>{
     if(err)throw err;
     res.send({code:1,data:result}) 
 })
})



// 根据id查询蛋糕商品信息
router.get('/cakeInfo',(req,res)=>{
    var id=req.query.id;
    console.log(id);
    if(!id){
        res.send("id required");
        return;
    }
    var sql='select * from gyk_products where id=?'
    pool.query(sql,[id],(err,result)=>{
        if(err) throw err;
        console.log(result)
        if(result.length>0){
            res.send(result[0])
        }else{
            res.send('商品不存在')
        }
    })
})
// 根据id查询面包商品信息
router.get('/breadInfo',(req,res)=>{
    var id=req.query.id;
    console.log(id);
    if(!id){
        res.send("id required");
        return;
    }
    var sql='select * from gyk_products where id=?'
    pool.query(sql,[id],(err,result)=>{
        if(err) throw err;
        console.log(result)
        if(result.length>0){
            res.send(result[0])
        }else{
            res.send('商品不存在')
        }
    })
})
// 根据id查询咖啡商品信息
router.get('/coffeeInfo',(req,res)=>{
    var id=req.query.id;
    console.log(id);
    if(!id){
        res.send("id required");
        return;
    }
    var sql='select * from gyk_products where id=?'
    pool.query(sql,[id],(err,result)=>{
        if(err) throw err;
        console.log(result)
        if(result.length>0){
            res.send(result[0])
        }else{
            res.send('商品不存在')
        }
    })
})



//功能8删除购物车中的一个商品
router.get("/delCartItem",(req,res)=>{
  //参数
  var id=req.query.id;
  console.log(id)
  //sql
  var sql="DELETE FROM gyk_cart WHERE id=?";
  //json
  pool.query(sql,[id],(err,result)=>{
      if(err)throw err;
      if(result.affectedRows>0){
          res.send({code:1,msg:"删除成功"})
      }else{
          res.send({code:-1,msg:"删除失败"})
      }
  })
})
//功能9购物车删除多个商品
router.get("/removeMItem",(req,res)=>{
  //参数
  var ids=req.query.ids;
  //sql
  var sql="DELETE FROM gyk_cart";
  sql+=" WHERE id IN ("+ids+")";
  //json
  pool.query(sql,(err,result)=>{
      if(err)throw err;
      if(result.affectedRows>0){
          res.send({code:1,msg:"删除成功"})
      }else{
          res.send({code:-1,msg:"删除失败"})
      }
  })
})
////功能10商品搜索
router.get("/search",(req,res)=>{
    //获取参数
    var key=req.query.key;
    var pno=req.query.pno;
    var pageSize=req.query.pageSize;
    if(!pno){
      pno=1;
    }
    if(!pageSize){
      pageSize=7;
    }
   //sql
    var sql=` SELECT id,title,price,count,subtitle`;
   sql+=` ,img_url`;
   sql+=` FROM gyk_products WHERE title LIKE ?`;
   sql+=` LIMIT ?,?`;
   //转整形
   var pageSize=parseInt(pageSize);
   var offset=(pno-1)*pageSize;
   pool.query(sql,["%"+key+"%",offset,pageSize],(err,result)=>{
     if(err)throw err;
     res.send({code:1,data:result})
   });//urlhttp://127.0.0.1:3000/index/search?key=&pno=1&pageSize=7
});
//导出路由
module.exports=router;