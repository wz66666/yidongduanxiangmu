SET NAMES UTF8;
DROP DATABASE IF EXISTS gyk;
CREATE DATABASE gyk CHARSET=UTF8;
USE gyk;
/*首页轮播图片*/
CREATE TABLE gyk_imges(
   id INT PRIMARY KEY AUTO_INCREMENT,
   img VARCHAR(128)
);
INSERT INTO gyk_imges VALUES
(NULL,'./img/banner/1.jpg'),
(NULL,'./img/banner/2.jpg'),
(NULL,'./img/banner/3.jpg'),
(NULL,'./img/banner/4.jpg');
/*蛋糕列表*/
CREATE TABLE gyk_products(
    id INT PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(64),
    price DECIMAL(7,2),
    count VARCHAR(64),/*规格*/
    subtitle VARCHAR(64),
    img_url VARCHAR(128),
    addcart  VARCHAR(64)
);
INSERT INTO gyk_products VALUES
(NULL,'Pompeii 庞贝',268.00,'个','情侣>情人节>','./img/2/1.jpg','加入购物车',"cake"),
(NULL,'松仁淡奶',298.00,'2.0磅','长辈>人气>','./img/2/2.jpg','加入购物车',"cake"),
(NULL,'东慕斯与焗芝士',298.00,'2.0磅','情侣>低温>生日>','./img/2/3.jpg','加入购物车',"cake"),
(NULL,'小重组(树莓套餐)',298.00,'160g','情侣>聚会>新品>','./img/2/4.jpg','加入购物车',"cake"),
(NULL,'可可岛',458.00,'2.0磅','聚会>新品>','./img/2/5.jpg','加入购物车',"cake"),
(NULL,'小重组(蓝莓套餐)',298.00,'160g','情侣>聚会>新品>','./img/2/6.jpg','加入购物车',"cake"),
(NULL,'榴莲飘飘',298.00,'2.0磅','人气>生日>','./img/2/7.jpg','加入购物车',"cake"),
(NULL,'黑白巧克力慕斯',298.00,'2.0磅','聚会>生日>人气>','./img/2/8.jpg','加入购物车',"cake"),
(NULL,'草莓奶油蛋糕',228.00,'2.0磅','情侣>人气>情人节>','./img/2/9.jpg','加入购物车',"cake"),
(NULL,'黑森林',398.00,'2.0磅','情侣>人气>','./img/2/10.jpg','加入购物车',"cake"),
(NULL,'庞贝',268.00,'个','新品>','./img/2/11.jpg','加入购物车',"cake"),
(NULL,'芒果奶油蛋糕',198.00,'2.0磅','情侣>儿童>聚会>','./img/2/13.jpg','加入购物车',"cake"),
(NULL,'浅草',298.00,'2.0磅','新品>人气>生日>','./img/2/14.jpg','加入购物车',"cake"),
(NULL,'百丽甜情人',298.00,'2.0磅','情侣>人气>生日>','./img/2/15.jpg','加入购物车',"cake"),
(NULL,'黑越橘',298.00,'2.0磅','人气>','./img/2/16.jpg','加入购物车',"cake"),
(NULL,'朗姆芝士',298.00,'2.0磅','情侣>生日>情人节>','./img/2/17.jpg','加入购物车',"cake"),
(NULL,'(新)栗蓉暗香',298.00,'2.0磅','儿童>聚会>长辈>','./img/2/18.jpg','加入购物车',"cake"),
(NULL,'黑白巧克力慕斯(千阳号)',358.00,'2.0磅','新品>儿童>','./img/2/19.jpg','加入购物车',"cake"),
(NULL,'小重组(迭迭香套餐)',298.00,'160g','情侣>新品>聚会>','./img/2/20.jpg','加入购物车',"cake"),
(NULL,'松仁淡奶(木糖醇)',298.00,'2.0磅','长辈>新品>','./img/2/21.jpg','加入购物车',"cake");





/*面包列表*/
CREATE TABLE gyk_products_b(
    id INT PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(64),
    price DECIMAL(7,2),
    count VARCHAR(64),/*规格*/
    subtitle VARCHAR(64),
    img_url VARCHAR(128),
    addcart  VARCHAR(64)
);
INSERT INTO gyk_products VALUES
(NULL,'元气满满组合',39.00,'一份','儿童>人气>面包>','./img/3/1.jpg','加入购物车',"bread"),
(NULL,'蓝莓丹麦',13.80,'一份','面包>儿童>女性>','./img/3/2.jpg','加入购物车',"bread"),
(NULL,'卜壳吐司(2片)',12.00,'一份','儿童>面包>','./img/3/3.jpg','加入购物车',"bread"),
(NULL,'卜壳吐司(家庭装)',32.00,'一份','面包>儿童>','./img/3/4.jpg','加入购物车',"bread"),
(NULL,'肉桂卷',13.00,'一份','人气>女性>面包>','./img/3/5.jpg','加入购物车',"bread"),
(NULL,'红糖红枣桂圆软欧',12.80,'一份','面包>女性>','./img/3/6.jpg','加入购物车',"bread"),
(NULL,'北海道吐司(4片)',13.80,'一份','面包>儿童>人气>','./img/3/7.jpg','加入购物车',"bread"),
(NULL,'榛子巧克力软欧',14.80,'一份','面包>人气>女性>','./img/3/8.jpg','加入购物车',"bread"),
(NULL,'玫瑰吐司(4片)',14.80,'一份','面包>人气>女性>','./img/3/10.jpg','加入购物车',"bread"),
(NULL,'核桃派',18.80,'一份','儿童>人气>面包>','./img/3/11.jpg','加入购物车',"bread"),
(NULL,'购磅数蛋糕，享39元换购',58.40,'一份','儿童>人气>','./img/3/12.jpg','加入购物车',"bread"),
(NULL,'阳光葡萄卷',13.80,'一份','儿童>面包>','./img/3/13.jpg','加入购物车',"bread");





/*咖啡列表*/
CREATE TABLE gyk_products_c(
    id INT PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(64),
    price DECIMAL(7,2),
    count VARCHAR(64),/*规格*/
    subtitle VARCHAR(64),
    img_url VARCHAR(128),
    addcart  VARCHAR(64)
);
INSERT INTO gyk_products VALUES
(NULL,'巴西挂耳咖啡盒装',100.00,'盒','...','./img/5/1.jpg','加入购物车',"coffee"),
(NULL,'巴西挂耳咖啡',10.00,'包','...','./img/5/2.jpg','加入购物车',"coffee"),
(NULL,'西达摩挂耳咖啡',10.00,'包','...','./img/5/3.jpg','加入购物车',"coffee"),
(NULL,'西达摩挂耳咖啡盒装',100.00,'盒','...','./img/5/4.jpg','加入购物车',"coffee"),
(NULL,'耶加雪菲挂耳咖啡盒装',10.00,'盒','...','./img/5/5.jpg','加入购物车',"coffee"),
(NULL,'耶加雪菲挂耳咖啡',10.00,'包','...','./img/5/6.jpg','加入购物车',"coffee"),
(NULL,'巴布亚新几内亚挂耳咖啡',10.00,'包','...','./img/5/7.jpg','加入购物车',"coffee"),
(NULL,'巴布亚新几内亚盒装',10.00,'盒','...','./img/5/8.jpg','加入购物车',"coffee"),
(NULL,'小切块-心语心愿',36.00,'份','...','./img/5/9.jpg','加入购物车',"coffee"),
(NULL,'小切块-栗蓉暗香',36.00,'份','...','./img/5/10.jpg','加入购物车',"coffee"),
(NULL,'小切块-新卡',36.00,'份','...','./img/5/11.jpg','加入购物车',"coffee"),
(NULL,'小切块-松仁淡奶',36.00,'份','...','./img/5/12.jpg','加入购物车',"coffee"),
(NULL,'小切块-黑白巧克力慕斯',36.00,'块','...','./img/5/13.jpg','加入购物车',"coffee"),
(NULL,'小切块-芒果慕斯',36.00,'份','...','./img/5/14.jpg','加入购物车',"coffee"),
(NULL,'小切块-浅草',36.00,'份','...','./img/5/15.jpg','加入购物车',"coffee");
/*创建用户登录列表*/
CREATE TABLE gyk_login(
    id INT PRIMARY KEY AUTO_INCREMENT,
    uname VARCHAR(25),
    upwd VARCHAR(32)
);
INSERT INTO gyk_login VALUES(NULL,'tom',md5('123')),
(NULL,'jerry',md5('123')),
(NULL,'mingming',md5('123')),
(NULL,'dingding',md5('123')),
(NULL,'dangdang',md5('123'));
/*购物车列表*/
CREATE TABLE gyk_cart(
    id INT PRIMARY KEY AUTO_INCREMENT,
    count INT,
    price DECIMAL(15,2),
    pid INT,
    uid INT
);